#include "graphics.hpp"
#include "widget.hpp"
#include "checkbox.hpp"
#include "textbox.hpp"
#include "button.hpp"
#include "spinbutton.hpp"
#include "listview.hpp"

#include <vector>
using namespace std;
using namespace genv;

void event_loop(vector<Widget*> & widgets) {
    event ev;
    int focus = -1;
    while(gin >> ev ) {
        if (ev.type == ev_mouse && ev.button==btn_left) {
            for (size_t i=0;i<widgets.size();i++) {
                if (widgets[i]->is_selected(ev.pos_x, ev.pos_y)) {
                        widgets[i]->setFocus(true);
                        focus = i;
                } else {
                        widgets[i]->setFocus(false);
                }
            }
        }
        if (focus!=-1) {
            widgets[focus]->handle(NULL, 0, ev);
        }
        for (size_t i=0;i<widgets.size();i++) {
            widgets[i]->draw();
        }
        gout << refresh;
    }
}

int main()
{
    gout.open(400,400);

    vector<Widget*> w;

    CheckBox * c1 = new CheckBox(NULL, 0, 10,10,30,30);
    CheckBox * c2 = new CheckBox(NULL, 0, 10,50,30,30);

    TextBox * t1 = new TextBox(NULL, 0, 50, 10, 340, 30);
    TextBox * t2 = new TextBox(NULL, 0, 50, 50, 340, 30);

    SpinButton * sb1 = new SpinButton(NULL, 0, 10, 100, 120, 30, 10, 0, 25);
    SpinButton * sb2 = new SpinButton(NULL, 0, 10, 140, 120, 30, 0, -10, 10);

    ListView * lv1 = new ListView(NULL, 0, 10, 200, 200, 30, 6);
	lv1->addValue("Bekescsaba");
	lv1->addValue("Budapest");
	lv1->addValue("Debrecen");
	lv1->addValue("Eger");
	lv1->addValue("Gyor");
	lv1->addValue("Kaposvar");
	lv1->addValue("Kecskemet");
	lv1->addValue("Miskolc");
	lv1->addValue("Nyiregyhaza");
	lv1->addValue("Pecs");
	lv1->addValue("Salgotarjan");
	lv1->addValue("Szeged");
	lv1->addValue("Szekszard");
	lv1->addValue("Szekesfehervar");
	lv1->addValue("Szolnok");
	lv1->addValue("Szombathely");
	lv1->addValue("Tatabanya");
	lv1->addValue("Veszprem");
	lv1->addValue("Zalaegerszeg");

    c1->add(w);
    c2->add(w);
    t1->add(w);
    t2->add(w);
    sb1->add(w);
    sb2->add(w);
    lv1->add(w);

    event_loop(w);

    return 0;
}
