#include "listview.hpp"

ListView::ListView(Widget * parent, int id, int x, int y, int sx, int sy, unsigned int number)
    : Widget(parent, id, x, y, sx, sy * number) {
	_number = number;
	_position = 0;
	_selected = 0;
	_textBoxes = new TextBox *[_number];
	for (unsigned int i = 0; i < _number; i++) {
		_textBoxes[i] = new TextBox(this, i, x, y + (i * sy), sx, sy);
		_textBoxes[i]->setBorder(false);
		_textBoxes[i]->setEdit(false);
	}
}

ListView::~ListView() {
	for (unsigned int i = 0; i < _number; i++) {
		delete _textBoxes[i];
	}
	delete [] _textBoxes;
}

void ListView::add(vector<Widget *> & widgets) {
  widgets.push_back(this);
	for (unsigned int i = 0; i < _number; i++) {
		widgets.push_back(_textBoxes[i]);
	}
}

void ListView::draw() const {
  Widget::draw();

	for (unsigned int i = 0; i < _number; i++) {
		if ((i + _position) < _values.size()) {
			_textBoxes[i]->setText(_values[i + _position].c_str());
		}
	}
}

void ListView::handle(Widget * source, int message, event ev) {
  if (_disabled == false) {
	bool up = false;
	bool down = false;

    if (ev.type == ev_key) {
        switch (ev.keycode) {
        case key_pgup :
        case key_up :
        case key_left : {
			up = true;
            break;
        }
        case key_pgdn :
        case key_down :
        case key_right : {
			down = true;
            break;
        }
        }
    }

    if (ev.type == ev_mouse) {
        switch (ev.button) {
        case btn_wheelup : {
			up = true;
            break;
        }
        case btn_wheeldown : {
			down = true;
            break;
        }
        }
    }

    if (source != NULL) {
        if (message == __MESSAGE__OnFocus) {
            _selected = source->getId();
		}
    }

    if (up== true) {
        if (_selected > 0) {
            _selected = _selected - 1;
        } else {
            if (_position > 0) {
                _position = _position - 1;
            }
        }

    }

    if (down == true) {
        if (_selected < (_number - 1)) {
            _selected = _selected + 1;
        } else {
            if ((_position + _number) < _values.size()) {
                _position = _position + 1;
            }
        }
    }

    if (message != __MESSAGE__OnFocus) {
        for (unsigned int i = 0; i < _number; i++) {
            if (i == _selected) {
                _textBoxes[i]->setFocus(true);
            } else {
                _textBoxes[i]->setFocus(false);
            }
        }
    }
  }
}

void ListView::addValue(const char * value) {
	_values.push_back(value);
}
